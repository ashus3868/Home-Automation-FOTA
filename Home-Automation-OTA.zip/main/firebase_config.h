// Wifi Credentials
#define SSID "OnePlus 12"
#define PASSWORD "12345678"

// Read readme.md to properly configure api key and authentication

// create a new api key and add it here 
#define API_KEY "BJZyIz3vaVD4HO6IKXNEc8TcbU00ZsncsFXohfEw"
// Copy your firebase real time database link here 
#define DATABASE_URL "https://esp-idf-fire-default-rtdb.firebaseio.com/"  

#define USER_EMAIL "ashus3868@gmail.com"   // This gmail does not exist outside your database. it only exists in the firebase project as a user
#define USER_PASSWORD "Ashu@123"      // Dont add your gmail credentials. Setup users authentication in your Firebase project first
